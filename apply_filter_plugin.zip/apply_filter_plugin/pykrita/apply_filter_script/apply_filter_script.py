from krita import Extension, Krita

class ApplyFilterExtension(Extension):
    def __init__(self, parent):
        super().__init__(parent)
    
    def setup(self):
        pass
    
    def createActions(self, window):
        action = window.createAction("apply_filter_to_layers", "Apply Filter to Selected Layers")
        action.triggered.connect(self.run_script)
    
    def run_script(self):
        app = Krita.instance()
        doc = app.activeDocument()
        if not doc:
            print("ERROR: No active document found.")
            return
        
        view = app.activeWindow().activeView()
        selected_nodes = view.selectedNodes()
        
        print(f"\n=== STARTING FILTER APPLICATION ===")
        print(f"Total selected nodes: {len(selected_nodes)}")
        
        # 1. Separate the Filter Layer from the Paint Layers
        filter_layer = None
        target_layers = []
        
        for node in selected_nodes:
            print(f"  Node: {node.name()} - Type: {node.type()}")
            if node.type() == "filterlayer":
                filter_layer = node
            elif node.type() == "paintlayer":
                target_layers.append(node)
        
        if not filter_layer:
            print("\nERROR: Select exactly ONE Filter Layer along with your target layers.")
            return
        if not target_layers:
            print("\nERROR: No valid target paint layers selected.")
            return
        
        print(f"\nFilter layer: {filter_layer.name()}")
        print(f"Target layers: {len(target_layers)}")
        
        print("\n--- Processing Layers ---")
        
        for paint_layer in reversed(target_layers):
            parent = paint_layer.parentNode()
            if not parent:
                print(f"SKIP: {paint_layer.name()} has no parent")
                continue
            
            # Save original properties
            orig_name = paint_layer.name()
            orig_blend = paint_layer.blendingMode()
            orig_opacity = paint_layer.opacity()
            orig_alpha = paint_layer.inheritAlpha()
            orig_locked = paint_layer.locked()
            
            print(f"\n[{orig_name}]")
            print(f"  Blend: {orig_blend}, Opacity: {orig_opacity}, Alpha: {orig_alpha}, Locked: {orig_locked}")
            
            if orig_locked:
                paint_layer.setLocked(False)
                print(f"  Unlocked layer")
            
            # CRITICAL: Temporarily disable Inherit Alpha before grouping
            if orig_alpha:
                paint_layer.setInheritAlpha(False)
                doc.refreshProjection()
                doc.waitForDone()
                print(f"  ✓ Disabled Inherit Alpha temporarily")
            
            # Create temporary group
            tmp_group = doc.createGroupLayer(f"__tmp_{orig_name}")
            parent.addChildNode(tmp_group, paint_layer)
            print(f"  ✓ Created temp group")
            
            # Move paint layer into group
            parent.removeChildNode(paint_layer)
            tmp_group.addChildNode(paint_layer, None)
            print(f"  ✓ Moved layer into group")
            
            # Add duplicated filter on top
            duplicated_filter = filter_layer.duplicate()
            tmp_group.addChildNode(duplicated_filter, paint_layer)
            print(f"  ✓ Added filter copy")
            
            # Flatten the group
            doc.setActiveNode(tmp_group)
            doc.refreshProjection()
            doc.waitForDone()
            
            print(f"  ⏳ Flattening...")
            app.action('flatten_layer').trigger()
            doc.waitForDone()
            print(f"  ✓ Flattened")
            
            # Get the flattened result
            result_layer = doc.activeNode()
            
            # Restore properties
            result_layer.setName(orig_name)
            result_layer.setBlendingMode(orig_blend)
            result_layer.setOpacity(orig_opacity)
            result_layer.setInheritAlpha(orig_alpha)
            
            if orig_locked:
                result_layer.setLocked(True)
            
            print(f"  ✓ Restored properties (Alpha: {orig_alpha})")
            print(f"  ✓ COMPLETED: {orig_name}")
        
        doc.refreshProjection()
        print("\n=== ✓ ALL LAYERS PROCESSED ===\n")

# Register the extension
Krita.instance().addExtension(ApplyFilterExtension(Krita.instance()))